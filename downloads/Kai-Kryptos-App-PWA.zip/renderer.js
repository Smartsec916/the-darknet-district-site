
const validToken = "admin-token";
const logURL = "/core-sync"; // Cleaner, internal path

function unlock() {
  const token = document.getElementById("token-input").value;
  if (token === validToken) {
    document.getElementById("unlock-section").style.display = "none";
    document.getElementById("log-section").style.display = "block";
    fetchLogs();
  } else {
    alert("Invalid token.");
  }
}

function toggleDarkMode() {
  const body = document.body;
  body.classList.toggle("dark");
  body.classList.remove("red");
}

function toggleRedAlert() {
  const body = document.body;
  body.classList.add("red");
  body.classList.remove("dark");
}

async function fetchLogs() {
  try {
    const response = await fetch(logURL, {
      headers: { Authorization: `Bearer ${validToken}` }
    });
    const data = await response.json();

    let logText = '';
    const map = L.map('map').setView([20, 0], 2);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap'
    }).addTo(map);

    data.forEach(log => {
      logText += JSON.stringify(log, null, 2) + "\n";

      if (log.geoData && log.geoData.latitude && log.geoData.longitude) {
        L.marker([log.geoData.latitude, log.geoData.longitude])
          .addTo(map)
          .bindPopup(`${log.geoData.city}, ${log.geoData.country_name}`);
      }
    });

    document.getElementById("logs").textContent = logText;
  } catch (err) {
    document.getElementById("logs").textContent = "Failed to load logs.";
  }
}
