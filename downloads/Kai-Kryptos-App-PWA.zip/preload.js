
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Add secure APIs if needed later
});
